import React, { useState } from 'react';
import { Shield, AlertTriangle, CheckCircle, Eye, Code, BookOpen } from 'lucide-react';
import XSSDemo from './components/XSSDemo';
import SecurityReport from './components/SecurityReport';
import VulnerabilityLabs from './components/VulnerabilityLabs';
import SecurityBestPractices from './components/SecurityBestPractices';

function App() {
  const [activeTab, setActiveTab] = useState('labs');

  const tabs = [
    { id: 'labs', label: 'Vulnerability Labs', icon: Code },
    { id: 'demo', label: 'XSS Demo', icon: AlertTriangle },
    { id: 'report', label: 'Security Reports', icon: Eye },
    { id: 'practices', label: 'Best Practices', icon: Shield }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-sm border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <Shield className="h-8 w-8 text-cyan-400" />
              <h1 className="text-xl font-bold text-white">Web Security Education Platform</h1>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span className="text-green-400 text-sm font-medium">Educational Use Only</span>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-black/10 backdrop-blur-sm border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8 py-4">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                    activeTab === tab.id
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                      : 'text-gray-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span className="font-medium">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'labs' && <VulnerabilityLabs />}
        {activeTab === 'demo' && <XSSDemo />}
        {activeTab === 'report' && <SecurityReport />}
        {activeTab === 'practices' && <SecurityBestPractices />}
      </main>

      {/* Footer */}
      <footer className="bg-black/20 backdrop-blur-sm border-t border-white/10 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-center space-x-2">
            <BookOpen className="h-5 w-5 text-gray-400" />
            <span className="text-gray-400">Educational platform for learning web security concepts</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;