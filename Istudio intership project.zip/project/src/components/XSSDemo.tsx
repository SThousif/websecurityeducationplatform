import React, { useState } from 'react';
import { AlertTriangle, Shield, Code, Eye } from 'lucide-react';

const XSSDemo = () => {
  const [userInput, setUserInput] = useState('');
  const [isVulnerable, setIsVulnerable] = useState(true);
  const [showOutput, setShowOutput] = useState(false);

  const sanitizeInput = (input: string) => {
    return input
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#x27;');
  };

  const getOutput = () => {
    if (isVulnerable) {
      return userInput;
    } else {
      return sanitizeInput(userInput);
    }
  };

  const commonPayloads = [
    '<script>alert("XSS")</script>',
    '<img src="x" onerror="alert(\'XSS\')">',
    '<svg onload="alert(1)">',
    'javascript:alert("XSS")',
    '<iframe src="data:text/html,<script>alert(1)</script>"></iframe>'
  ];

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-4">Cross-Site Scripting (XSS) Demo</h2>
        <p className="text-gray-300 max-w-2xl mx-auto">
          Learn about XSS vulnerabilities and how proper input sanitization prevents them.
          This is a safe, educational demonstration.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Input Section */}
        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50">
          <h3 className="text-xl font-semibold text-white mb-4 flex items-center space-x-2">
            <Code className="h-5 w-5" />
            <span>Input Testing</span>
          </h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                User Input
              </label>
              <textarea
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                placeholder="Enter some text or HTML..."
                className="w-full h-32 px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => setIsVulnerable(!isVulnerable)}
                  className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                    isVulnerable
                      ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                      : 'bg-green-500/20 text-green-400 border border-green-500/30'
                  }`}
                >
                  {isVulnerable ? (
                    <><AlertTriangle className="h-4 w-4 inline mr-2" />Vulnerable</>
                  ) : (
                    <><Shield className="h-4 w-4 inline mr-2" />Protected</>
                  )}
                </button>
              </div>

              <button
                onClick={() => setShowOutput(true)}
                className="px-4 py-2 bg-cyan-500 hover:bg-cyan-600 text-white rounded-lg transition-colors duration-200 flex items-center space-x-2"
              >
                <Eye className="h-4 w-4" />
                <span>Render Output</span>
              </button>
            </div>
          </div>
        </div>

        {/* Output Section */}
        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50">
          <h3 className="text-xl font-semibold text-white mb-4">Output Preview</h3>

          {showOutput ? (
            <div className="space-y-4">
              <div className="bg-slate-900 rounded-lg p-4 border-2 border-dashed border-slate-600">
                <div className="text-gray-300 text-sm mb-2">Rendered Output:</div>
                <div 
                  className="bg-white p-3 rounded text-gray-900 min-h-[80px]"
                  dangerouslySetInnerHTML={{ __html: getOutput() }}
                />
              </div>

              <div className="bg-slate-900 rounded-lg p-4">
                <div className="text-gray-300 text-sm mb-2">Raw HTML:</div>
                <code className="text-green-400 text-sm break-all">
                  {getOutput()}
                </code>
              </div>

              {isVulnerable && userInput.includes('<script>') && (
                <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <AlertTriangle className="h-4 w-4 text-red-400" />
                    <span className="text-red-400 font-medium">XSS Vulnerability Detected!</span>
                  </div>
                  <p className="text-gray-300 text-sm">
                    This input contains potentially malicious scripts that would execute in a real application.
                  </p>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-12 text-gray-400">
              <Eye className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Click "Render Output" to see the result</p>
            </div>
          )}
        </div>
      </div>

      {/* Common Payloads */}
      <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50">
        <h3 className="text-xl font-semibold text-white mb-4">Common XSS Payloads (Educational)</h3>
        <div className="grid gap-3">
          {commonPayloads.map((payload, index) => (
            <button
              key={index}
              onClick={() => setUserInput(payload)}
              className="text-left p-3 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors duration-200"
            >
              <code className="text-yellow-400 text-sm">{payload}</code>
            </button>
          ))}
        </div>
      </div>

      {/* Prevention Tips */}
      <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-green-400 mb-4 flex items-center space-x-2">
          <Shield className="h-5 w-5" />
          <span>XSS Prevention Best Practices</span>
        </h3>
        <ul className="space-y-2 text-gray-300">
          <li>• Always sanitize and validate user input</li>
          <li>• Use proper output encoding (HTML entities)</li>
          <li>• Implement Content Security Policy (CSP) headers</li>
          <li>• Use secure coding practices and frameworks</li>
          <li>• Regular security testing and code reviews</li>
        </ul>
      </div>
    </div>
  );
};

export default XSSDemo;