import React, { useState } from 'react';
import { FileText, Camera, Video, AlertTriangle, Info, CheckCircle } from 'lucide-react';

const SecurityReport = () => {
  const [reportData, setReportData] = useState({
    title: '',
    severity: 'Medium',
    description: '',
    stepsToReproduce: '',
    impact: '',
    recommendations: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setReportData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'Critical': return 'text-red-400 bg-red-400/10 border-red-400/20';
      case 'High': return 'text-orange-400 bg-orange-400/10 border-orange-400/20';
      case 'Medium': return 'text-yellow-400 bg-yellow-400/10 border-yellow-400/20';
      case 'Low': return 'text-green-400 bg-green-400/10 border-green-400/20';
      default: return 'text-gray-400 bg-gray-400/10 border-gray-400/20';
    }
  };

  const exampleReport = {
    title: "Reflected XSS in Search Parameter",
    severity: "High",
    description: "A reflected cross-site scripting vulnerability was discovered in the search functionality. User input is directly reflected in the response without proper sanitization.",
    stepsToReproduce: `1. Navigate to the search page
2. Enter the following payload in the search field: <script>alert('XSS')</script>
3. Submit the form
4. Observe that the script executes in the browser`,
    impact: "An attacker could exploit this vulnerability to execute malicious JavaScript in victims' browsers, potentially leading to session hijacking, credential theft, or defacement.",
    recommendations: `1. Implement proper input validation on all user inputs
2. Use output encoding when displaying user data
3. Implement Content Security Policy (CSP) headers
4. Regular security testing and code reviews`
  };

  const loadExample = () => {
    setReportData(exampleReport);
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-4">Security Vulnerability Report Template</h2>
        <p className="text-gray-300 max-w-2xl mx-auto">
          Learn how to properly document security vulnerabilities with comprehensive reports
          that include all necessary details for remediation.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Report Form */}
        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold text-white flex items-center space-x-2">
              <FileText className="h-5 w-5" />
              <span>Report Builder</span>
            </h3>
            <button
              onClick={loadExample}
              className="px-3 py-1 text-sm bg-cyan-500/20 text-cyan-400 rounded border border-cyan-500/30 hover:bg-cyan-500/30 transition-colors"
            >
              Load Example
            </button>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Vulnerability Title
              </label>
              <input
                type="text"
                value={reportData.title}
                onChange={(e) => handleInputChange('title', e.target.value)}
                placeholder="e.g., Reflected XSS in Search Parameter"
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Severity Level
              </label>
              <select
                value={reportData.severity}
                onChange={(e) => handleInputChange('severity', e.target.value)}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              >
                <option value="Critical">Critical</option>
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Description
              </label>
              <textarea
                value={reportData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                placeholder="Describe the vulnerability and how it was discovered..."
                rows={3}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Steps to Reproduce
              </label>
              <textarea
                value={reportData.stepsToReproduce}
                onChange={(e) => handleInputChange('stepsToReproduce', e.target.value)}
                placeholder="1. Navigate to...&#10;2. Enter payload...&#10;3. Submit form..."
                rows={4}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Impact Assessment
              </label>
              <textarea
                value={reportData.impact}
                onChange={(e) => handleInputChange('impact', e.target.value)}
                placeholder="Explain the potential impact if this vulnerability is exploited..."
                rows={3}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Recommendations
              </label>
              <textarea
                value={reportData.recommendations}
                onChange={(e) => handleInputChange('recommendations', e.target.value)}
                placeholder="Provide specific recommendations for fixing this vulnerability..."
                rows={4}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
            </div>
          </div>
        </div>

        {/* Report Preview */}
        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50">
          <h3 className="text-xl font-semibold text-white mb-6">Report Preview</h3>

          <div className="space-y-6">
            {/* Header */}
            <div className="border-b border-slate-700 pb-4">
              <h4 className="text-lg font-semibold text-white mb-2">
                {reportData.title || 'Vulnerability Title'}
              </h4>
              <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getSeverityColor(reportData.severity)}`}>
                {reportData.severity} Severity
              </span>
            </div>

            {/* Description */}
            <div>
              <h5 className="text-sm font-medium text-gray-300 mb-2 flex items-center space-x-2">
                <Info className="h-4 w-4" />
                <span>Description</span>
              </h5>
              <p className="text-gray-400 text-sm">
                {reportData.description || 'No description provided'}
              </p>
            </div>

            {/* Steps */}
            <div>
              <h5 className="text-sm font-medium text-gray-300 mb-2">Steps to Reproduce</h5>
              <div className="bg-slate-900 rounded-lg p-3">
                <pre className="text-gray-400 text-sm whitespace-pre-wrap">
                  {reportData.stepsToReproduce || 'No steps provided'}
                </pre>
              </div>
            </div>

            {/* Impact */}
            <div>
              <h5 className="text-sm font-medium text-gray-300 mb-2 flex items-center space-x-2">
                <AlertTriangle className="h-4 w-4" />
                <span>Impact</span>
              </h5>
              <p className="text-gray-400 text-sm">
                {reportData.impact || 'No impact assessment provided'}
              </p>
            </div>

            {/* Recommendations */}
            <div>
              <h5 className="text-sm font-medium text-gray-300 mb-2 flex items-center space-x-2">
                <CheckCircle className="h-4 w-4" />
                <span>Recommendations</span>
              </h5>
              <div className="bg-slate-900 rounded-lg p-3">
                <pre className="text-gray-400 text-sm whitespace-pre-wrap">
                  {reportData.recommendations || 'No recommendations provided'}
                </pre>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Report Components */}
      <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50">
        <h3 className="text-xl font-semibold text-white mb-4">Essential Report Components</h3>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="bg-blue-500/10 w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-3">
              <FileText className="h-6 w-6 text-blue-400" />
            </div>
            <h4 className="font-medium text-white mb-2">Detailed Steps</h4>
            <p className="text-gray-400 text-sm">Clear, reproducible steps that anyone can follow</p>
          </div>
          <div className="text-center">
            <div className="bg-green-500/10 w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Camera className="h-6 w-6 text-green-400" />
            </div>
            <h4 className="font-medium text-white mb-2">Screenshots</h4>
            <p className="text-gray-400 text-sm">Visual evidence of the vulnerability</p>
          </div>
          <div className="text-center">
            <div className="bg-purple-500/10 w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Video className="h-6 w-6 text-purple-400" />
            </div>
            <h4 className="font-medium text-white mb-2">Video Proof</h4>
            <p className="text-gray-400 text-sm">Screen recording demonstrating the exploit</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecurityReport;