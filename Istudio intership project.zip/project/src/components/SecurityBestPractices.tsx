import React from 'react';
import { Shield, Lock, Eye, Code, AlertTriangle, CheckCircle } from 'lucide-react';

const SecurityBestPractices = () => {
  const practices = [
    {
      icon: Shield,
      title: 'Input Validation',
      description: 'Always validate and sanitize user input on both client and server sides',
      examples: [
        'Use whitelist validation instead of blacklist',
        'Implement proper data type validation',
        'Set maximum length limits for inputs',
        'Use parameterized queries for database operations'
      ]
    },
    {
      icon: Lock,
      title: 'Output Encoding',
      description: 'Properly encode data when displaying it to prevent XSS attacks',
      examples: [
        'HTML entity encoding for HTML contexts',
        'JavaScript escaping for JS contexts',
        'URL encoding for URL parameters',
        'CSS escaping for style contexts'
      ]
    },
    {
      icon: Eye,
      title: 'Security Headers',
      description: 'Implement security headers to protect against various attacks',
      examples: [
        'Content Security Policy (CSP)',
        'X-Frame-Options to prevent clickjacking',
        'X-XSS-Protection for XSS filtering',
        'Strict-Transport-Security for HTTPS'
      ]
    },
    {
      icon: Code,
      title: 'Secure Coding',
      description: 'Follow secure coding practices throughout development',
      examples: [
        'Use secure frameworks and libraries',
        'Regular dependency updates',
        'Implement proper error handling',
        'Use secure session management'
      ]
    }
  ];

  const vulnerabilityTypes = [
    {
      name: 'Cross-Site Scripting (XSS)',
      severity: 'High',
      description: 'Malicious scripts executed in user browsers',
      prevention: 'Input validation, output encoding, CSP headers'
    },
    {
      name: 'SQL Injection',
      severity: 'Critical',
      description: 'Malicious SQL queries executed on database',
      prevention: 'Parameterized queries, input validation, least privilege'
    },
    {
      name: 'Cross-Site Request Forgery (CSRF)',
      severity: 'Medium',
      description: 'Unauthorized actions performed on behalf of users',
      prevention: 'CSRF tokens, SameSite cookies, origin validation'
    },
    {
      name: 'Insecure Direct Object References',
      severity: 'High',
      description: 'Unauthorized access to objects by manipulating references',
      prevention: 'Access controls, indirect references, authorization checks'
    }
  ];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'Critical': return 'text-red-400 bg-red-400/10';
      case 'High': return 'text-orange-400 bg-orange-400/10';
      case 'Medium': return 'text-yellow-400 bg-yellow-400/10';
      case 'Low': return 'text-green-400 bg-green-400/10';
      default: return 'text-gray-400 bg-gray-400/10';
    }
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-4">Web Security Best Practices</h2>
        <p className="text-gray-300 max-w-2xl mx-auto">
          Comprehensive guidelines for building secure web applications and protecting against
          common vulnerabilities and attacks.
        </p>
      </div>

      {/* Security Practices */}
      <div className="grid md:grid-cols-2 gap-6">
        {practices.map((practice, index) => {
          const Icon = practice.icon;
          return (
            <div key={index} className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50">
              <div className="flex items-center space-x-3 mb-4">
                <div className="bg-cyan-500/10 w-10 h-10 rounded-lg flex items-center justify-center">
                  <Icon className="h-5 w-5 text-cyan-400" />
                </div>
                <h3 className="text-lg font-semibold text-white">{practice.title}</h3>
              </div>
              
              <p className="text-gray-300 mb-4">{practice.description}</p>
              
              <div className="space-y-2">
                {practice.examples.map((example, idx) => (
                  <div key={idx} className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-400 flex-shrink-0" />
                    <span className="text-gray-400 text-sm">{example}</span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Common Vulnerabilities */}
      <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50">
        <h3 className="text-xl font-semibold text-white mb-6 flex items-center space-x-2">
          <AlertTriangle className="h-5 w-5" />
          <span>Common Web Vulnerabilities</span>
        </h3>
        
        <div className="grid gap-4">
          {vulnerabilityTypes.map((vuln, index) => (
            <div key={index} className="bg-slate-900/50 rounded-lg p-4 border border-slate-700/30">
              <div className="flex items-start justify-between mb-2">
                <h4 className="font-medium text-white">{vuln.name}</h4>
                <span className={`px-2 py-1 rounded text-xs font-medium ${getSeverityColor(vuln.severity)}`}>
                  {vuln.severity}
                </span>
              </div>
              <p className="text-gray-400 text-sm mb-3">{vuln.description}</p>
              <div className="bg-green-500/10 border border-green-500/20 rounded p-3">
                <div className="flex items-center space-x-2 mb-1">
                  <Shield className="h-3 w-3 text-green-400" />
                  <span className="text-green-400 text-xs font-medium">Prevention</span>
                </div>
                <p className="text-gray-300 text-xs">{vuln.prevention}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Security Testing Checklist */}
      <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50">
        <h3 className="text-xl font-semibold text-white mb-6">Security Testing Checklist</h3>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-medium text-white mb-3">Input Validation Testing</h4>
            <div className="space-y-2">
              {[
                'Test with malicious payloads',
                'Verify length limits',
                'Check special character handling',
                'Test different input types'
              ].map((item, idx) => (
                <div key={idx} className="flex items-center space-x-2">
                  <div className="w-4 h-4 border border-gray-600 rounded"></div>
                  <span className="text-gray-400 text-sm">{item}</span>
                </div>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="font-medium text-white mb-3">Authentication Testing</h4>
            <div className="space-y-2">
              {[
                'Test password policies',
                'Verify session management',
                'Check for brute force protection',
                'Test logout functionality'
              ].map((item, idx) => (
                <div key={idx} className="flex items-center space-x-2">
                  <div className="w-4 h-4 border border-gray-600 rounded"></div>
                  <span className="text-gray-400 text-sm">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Resources */}
      <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-blue-400 mb-4">Additional Resources</h3>
        <div className="grid md:grid-cols-2 gap-4 text-sm">
          <div>
            <h4 className="text-white font-medium mb-2">Learning Platforms</h4>
            <ul className="space-y-1 text-gray-300">
              <li>• OWASP WebGoat</li>
              <li>• PortSwigger Web Security Academy</li>
              <li>• HackerOne CTF</li>
              <li>• VulnHub</li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-medium mb-2">Security Guidelines</h4>
            <ul className="space-y-1 text-gray-300">
              <li>• OWASP Top 10</li>
              <li>• NIST Cybersecurity Framework</li>
              <li>• CIS Controls</li>
              <li>• SANS Secure Coding Practices</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecurityBestPractices;